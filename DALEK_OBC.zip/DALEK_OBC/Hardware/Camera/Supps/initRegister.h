/*
 * initRegister.h
 *
 *  Created on: Dec 14, 2015
 *      Author: arthur
 */

#ifndef HARDWARE_CAMERA_SUPPS_INITREGISTER_H_
#define HARDWARE_CAMERA_SUPPS_INITREGISTER_H_



extern uint8_t init_registers[][2];



#endif /* HARDWARE_CAMERA_SUPPS_INITREGISTER_H_ */

/*
 * audioPlayback.h
 *
 *  Created on: Nov 30, 2015
 *      Author: arthur
 */

#ifndef HARDWARE_AUDIO_AUDIOPLAYBACK_H_
#define HARDWARE_AUDIO_AUDIOPLAYBACK_H_

class audioPlayback {
public:
	audioPlayback();
	virtual ~audioPlayback();
};

#endif /* HARDWARE_AUDIO_AUDIOPLAYBACK_H_ */
